import os.path
print os.getcwd.__doc__
      
