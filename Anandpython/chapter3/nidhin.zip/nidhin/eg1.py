def time():
	import time
	print time.asctime()





time()
